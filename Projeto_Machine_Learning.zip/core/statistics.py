def to_float(value):
    if value is None:
        return None

    value = str(value).strip()

    if value == "" or value == "-9999" or value == "null":
        return None

    value = value.replace(",", ".")

    try:
        return float(value)
    except:
        return None


def sqrt_newton(x, precision=1e-10):
    if x < 0:
        return None
    if x == 0:
        return 0

    guess = x / 2 if x > 1 else 1

    for _ in range(100):
        new_guess = 0.5 * (guess + x / guess)
        if abs(new_guess - guess) < precision:
            return new_guess
        guess = new_guess

    return guess


def clean(values):
    return [v for v in values if v is not None]


def mean(values):
    values = clean(values)
    if len(values) == 0:
        return None
    return sum(values) / len(values)


def median(values):
    values = sorted(clean(values))
    n = len(values)

    if n == 0:
        return None

    mid = n // 2

    if n % 2 == 1:
        return values[mid]

    return (values[mid - 1] + values[mid]) / 2


def mode(values):
    values = clean(values)

    if len(values) == 0:
        return None

    freq = {}

    for v in values:
        key = round(v, 2)
        freq[key] = freq.get(key, 0) + 1

    max_count = max(freq.values())

    modes = [k for k, v in freq.items() if v == max_count]

    return modes


def variance(values, sample=True):
    values = clean(values)
    n = len(values)

    if n < 2:
        return None

    avg = mean(values)

    total = 0
    for v in values:
        total += (v - avg) ** 2

    divisor = n - 1 if sample else n

    return total / divisor


def std_dev(values, sample=True):
    var = variance(values, sample)

    if var is None:
        return None

    return sqrt_newton(var)


def covariance(x, y):
    pairs = [(x[i], y[i]) for i in range(min(len(x), len(y)))
             if x[i] is not None and y[i] is not None]

    n = len(pairs)

    if n < 2:
        return None

    xs = [p[0] for p in pairs]
    ys = [p[1] for p in pairs]

    mx = mean(xs)
    my = mean(ys)

    total = 0

    for i in range(n):
        total += (xs[i] - mx) * (ys[i] - my)

    return total / (n - 1)


def pearson(x, y):
    pairs = [(x[i], y[i]) for i in range(min(len(x), len(y)))
             if x[i] is not None and y[i] is not None]

    n = len(pairs)

    if n < 2:
        return None

    xs = [p[0] for p in pairs]
    ys = [p[1] for p in pairs]

    mx = mean(xs)
    my = mean(ys)

    numerator = 0
    sx = 0
    sy = 0

    for i in range(n):
        dx = xs[i] - mx
        dy = ys[i] - my

        numerator += dx * dy
        sx += dx ** 2
        sy += dy ** 2

    denominator = sqrt_newton(sx * sy)

    if denominator == 0:
        return None

    return numerator / denominator


def interpret_pearson(r):
    if r is None:
        return "Correlação insuficiente"

    direction = "positiva" if r > 0 else "negativa"

    ar = abs(r)

    if ar < 0.10:
        strength = "desprezível"
    elif ar < 0.30:
        strength = "fraca"
    elif ar < 0.50:
        strength = "moderada"
    elif ar < 0.70:
        strength = "forte"
    else:
        strength = "muito forte"

    return f"Correlação {direction} {strength}"


def cohen_d(group1, group2):
    group1 = clean(group1)
    group2 = clean(group2)

    n1 = len(group1)
    n2 = len(group2)

    if n1 < 2 or n2 < 2:
        return None

    m1 = mean(group1)
    m2 = mean(group2)

    v1 = variance(group1)
    v2 = variance(group2)

    pooled = ((n1 - 1) * v1 + (n2 - 1) * v2) / (n1 + n2 - 2)
    s = sqrt_newton(pooled)

    if s == 0:
        return None

    return (m1 - m2) / s


def interpret_cohen(d):
    if d is None:
        return "Efeito insuficiente"

    ad = abs(d)

    if ad < 0.20:
        return "efeito desprezível"
    elif ad < 0.50:
        return "efeito pequeno"
    elif ad < 0.80:
        return "efeito médio"
    else:
        return "efeito grande"