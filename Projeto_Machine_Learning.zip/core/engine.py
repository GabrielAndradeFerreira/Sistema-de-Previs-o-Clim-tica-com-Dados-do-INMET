from datetime import datetime
from core.probability import forecast_variable, rain_probability
from core.statistics import pearson, interpret_pearson
import unicodedata


def normalize_text(text):
    if text is None:
        return ""

    text = str(text).lower().strip()

    text = unicodedata.normalize("NFD", text)
    text = "".join(c for c in text if unicodedata.category(c) != "Mn")

    return text


class ClimateEngine:
    def __init__(self):
        self.stations = []

    def add_station(self, station_data):
        self.stations.append(station_data)

    def find_station(self, cidade=None, estado=None, estacao=None, regiao=None):
        result = []

        cidade_norm = normalize_text(cidade)
        estado_norm = normalize_text(estado)
        estacao_norm = normalize_text(estacao)
        regiao_norm = normalize_text(regiao)

        for s in self.stations:
            station_city = normalize_text(s.get("cidade"))
            station_state = normalize_text(s.get("estado"))
            station_code = normalize_text(s.get("estacao"))
            station_region = normalize_text(s.get("regiao"))

            if cidade and cidade_norm not in station_city:
                continue

            if estado and estado_norm != station_state:
                continue

            if estacao and estacao_norm != station_code:
                continue

            if regiao and regiao_norm != station_region:
                continue

            result.append(s)

        return result

    def forecast(self, date_str, cidade=None, estado=None, estacao=None, regiao=None):
        target_date = datetime.strptime(date_str, "%Y-%m-%d")

        matches = self.find_station(
            cidade=cidade,
            estado=estado,
            estacao=estacao,
            regiao=regiao
        )

        outputs = []

        for station in matches:
            temp = forecast_variable(station["dados"], target_date, "temperatura")
            humidity = forecast_variable(station["dados"], target_date, "umidade")
            pressure = forecast_variable(station["dados"], target_date, "pressao")
            wind = forecast_variable(station["dados"], target_date, "vento_velocidade")
            rain = rain_probability(station["dados"], target_date)

            hum_values = [r.get("umidade") for r in station["dados"]]
            rain_values = [r.get("precipitacao") for r in station["dados"]]

            corr = pearson(hum_values, rain_values)

            outputs.append({
                "local_consultado": f"{station.get('cidade')}/{station.get('estado')}",
                "estacao": station.get("estacao"),
                "periodo": date_str,
                "regiao": station.get("regiao"),
                "temperatura_media_prevista": round(temp["valor_previsto"], 2) if temp else None,
                "umidade_prevista": round(humidity["valor_previsto"], 2) if humidity else None,
                "pressao_prevista": round(pressure["valor_previsto"], 2) if pressure else None,
                "vento_previsto": round(wind["valor_previsto"], 2) if wind else None,
                "probabilidade_chuva": rain["probabilidade_chuva"],
                "correlacao_dominante": {
                    "variaveis": "umidade x precipitacao",
                    "valor": round(corr, 4) if corr is not None else None,
                    "interpretacao": interpret_pearson(corr)
                },
                "metodo": "regressao_linear_manual + media_movel + frequencia_historica",
                "confiabilidade": temp["confiabilidade"] if temp else None,
                "explicacao": self.explain(temp, rain, corr)
            })

        return outputs

    def explain(self, temp, rain, corr):
        parts = []

        if temp:
            parts.append(
                f"A temperatura foi estimada combinando média sazonal "
                f"({round(temp['media_sazonal'], 2)}), tendência linear e média móvel."
            )

        parts.append(
            "A probabilidade de chuva considera frequência histórica mensal "
            "e correlação entre umidade e precipitação."
        )

        if corr is not None:
            parts.append(
                f"A correlação umidade x precipitação foi {round(corr, 3)}, "
                f"classificada como {interpret_pearson(corr)}."
            )

        return " ".join(parts)