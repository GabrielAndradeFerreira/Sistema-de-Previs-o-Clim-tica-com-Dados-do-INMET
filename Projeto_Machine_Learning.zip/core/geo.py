from core.statistics import sqrt_newton, pearson


def simple_distance_km(lat1, lon1, lat2, lon2):
    if None in [lat1, lon1, lat2, lon2]:
        return None

    # Aproximação simples suficiente para similaridade climática regional
    km_per_degree = 111

    dx = (lat1 - lat2) * km_per_degree
    dy = (lon1 - lon2) * km_per_degree

    return sqrt_newton(dx * dx + dy * dy)


def align_by_datetime(station_a, station_b, variable):
    map_a = {}

    for r in station_a["dados"]:
        if r.get(variable) is not None:
            map_a[r["datetime"]] = r.get(variable)

    x = []
    y = []

    for r in station_b["dados"]:
        dt = r["datetime"]

        if dt in map_a and r.get(variable) is not None:
            x.append(map_a[dt])
            y.append(r.get(variable))

    return x, y


def spatial_correlation(station_a, station_b, variable):
    x, y = align_by_datetime(station_a, station_b, variable)

    corr = pearson(x, y)

    dist = simple_distance_km(
        station_a.get("latitude"),
        station_a.get("longitude"),
        station_b.get("latitude"),
        station_b.get("longitude")
    )

    similarity = None

    if corr is not None and dist is not None:
        similarity = corr / (1 + dist / 500)

    return {
        "estacao_a": station_a.get("estacao"),
        "estacao_b": station_b.get("estacao"),
        "variavel": variable,
        "correlacao": corr,
        "distancia_km": dist,
        "similaridade_climatica": similarity
    }