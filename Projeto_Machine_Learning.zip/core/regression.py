from core.statistics import mean


def linear_regression(x, y):
    pairs = [(x[i], y[i]) for i in range(min(len(x), len(y)))
             if x[i] is not None and y[i] is not None]

    n = len(pairs)

    if n < 2:
        return None

    xs = [p[0] for p in pairs]
    ys = [p[1] for p in pairs]

    sum_x = sum(xs)
    sum_y = sum(ys)
    sum_xy = sum(xs[i] * ys[i] for i in range(n))
    sum_x2 = sum(xs[i] ** 2 for i in range(n))

    denominator = n * sum_x2 - sum_x ** 2

    if denominator == 0:
        return None

    b = (n * sum_xy - sum_x * sum_y) / denominator
    a = mean(ys) - b * mean(xs)

    return {
        "a": a,
        "b": b
    }


def predict(model, x):
    return model["a"] + model["b"] * x


def mae(real, predicted):
    errors = []

    for i in range(min(len(real), len(predicted))):
        if real[i] is not None and predicted[i] is not None:
            errors.append(abs(real[i] - predicted[i]))

    if len(errors) == 0:
        return None

    return sum(errors) / len(errors)


def r2_score(real, predicted):
    pairs = [(real[i], predicted[i]) for i in range(min(len(real), len(predicted)))
             if real[i] is not None and predicted[i] is not None]

    if len(pairs) < 2:
        return None

    ys = [p[0] for p in pairs]
    yh = [p[1] for p in pairs]

    avg = sum(ys) / len(ys)

    ss_total = sum((y - avg) ** 2 for y in ys)
    ss_res = sum((ys[i] - yh[i]) ** 2 for i in range(len(ys)))

    if ss_total == 0:
        return None

    return 1 - ss_res / ss_total


def moving_average(values, window=5):
    result = []

    for i in range(len(values)):
        start = max(0, i - window + 1)
        subset = [v for v in values[start:i + 1] if v is not None]

        if len(subset) == 0:
            result.append(None)
        else:
            result.append(sum(subset) / len(subset))

    return result


def exponential_smoothing(values, alpha=0.35):
    result = []
    last = None

    for v in values:
        if v is None:
            result.append(last)
            continue

        if last is None:
            last = v
        else:
            last = alpha * v + (1 - alpha) * last

        result.append(last)

    return result