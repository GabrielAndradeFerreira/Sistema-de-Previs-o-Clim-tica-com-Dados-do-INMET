import matplotlib.pyplot as plt


def plot_time_series(records, variable, title):
    xs = []
    ys = []

    for r in records:
        if r.get(variable) is not None:
            xs.append(r["datetime"])
            ys.append(r[variable])

    plt.figure(figsize=(12, 5))
    plt.plot(xs, ys)
    plt.title(title)
    plt.xlabel("Data")
    plt.ylabel(variable)
    plt.grid(True)
    plt.show()


def plot_scatter(x, y, xlabel, ylabel, title):
    plt.figure(figsize=(7, 5))
    plt.scatter(x, y)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True)
    plt.show()