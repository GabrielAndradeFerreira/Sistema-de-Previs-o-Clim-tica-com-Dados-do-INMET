import csv
from datetime import datetime
from core.statistics import to_float


COLUMN_MAP = {
    "precipitacao": 0,
    "pressao": 1,
    "pressao_max": 2,
    "pressao_min": 3,
    "radiacao": 4,
    "temperatura": 5,
    "ponto_orvalho": 6,
    "temperatura_max": 7,
    "temperatura_min": 8,
    "orvalho_max": 9,
    "orvalho_min": 10,
    "umidade_max": 11,
    "umidade_min": 12,
    "umidade": 13,
    "vento_direcao": 14,
    "vento_rajada": 15,
    "vento_velocidade": 16
}


def parse_metadata_line(line, meta):
    text = line.upper()

    if "ESTACAO:" in text:
        meta["cidade"] = line.split("ESTACAO:")[-1].replace(";", "").strip()
        meta["estacao_nome"] = meta["cidade"]

    if "CODIGO" in text or "WMO" in text:
        meta["estacao"] = line.split(":")[-1].replace(";", "").strip()

    if "UF:" in text:
        meta["estado"] = line.split("UF:")[-1].replace(";", "").strip()

    if "REGIAO:" in text:
        parts = line.split(";")
        if len(parts) > 1:
            meta["regiao"] = parts[1].replace("S:", "").strip()

    if "LATITUDE:" in text:
        meta["latitude"] = to_float(line.split(":")[-1].replace(";", ""))

    if "LONGITUDE:" in text:
        meta["longitude"] = to_float(line.split(":")[-1].replace(";", ""))

    if "ALTITUDE:" in text:
        meta["altitude"] = to_float(line.split(":")[-1].replace(";", ""))


def detect_season(month):
    # Hemisfério Sul
    if month in [12, 1, 2]:
        return "verao"
    if month in [3, 4, 5]:
        return "outono"
    if month in [6, 7, 8]:
        return "inverno"
    return "primavera"


def parse_inmet_file(path):
    meta = {
        "estacao": None,
        "estacao_nome": None,
        "cidade": None,
        "estado": None,
        "regiao": None,
        "latitude": None,
        "longitude": None,
        "altitude": None,
        "dados": []
    }

    with open(path, "r", encoding="latin1") as f:
        lines = f.readlines()

    data_started = False

    for raw in lines:
        line = raw.strip()

        if not line:
            continue

        if not data_started:
            parse_metadata_line(line, meta)

        if "DATA" in line.upper() and "HORA" in line.upper():
            data_started = True
            continue

        if data_started:
            parts = line.split(";")

            date_index = None

            for i, p in enumerate(parts):
                if "/" in p and len(p.strip()) >= 8:
                    date_index = i
                    break

            if date_index is None:
                continue

            try:
                date_str = parts[date_index].strip()
                hour_str = parts[date_index + 1].replace("UTC", "").strip()

                dt = datetime.strptime(
                    date_str + " " + hour_str,
                    "%Y/%m/%d %H%M"
                )
            except:
                continue

            values = parts[date_index + 2:]

            record = {
                "datetime": dt,
                "ano": dt.year,
                "mes": dt.month,
                "dia": dt.day,
                "hora": dt.hour,
                "estacao_ano": detect_season(dt.month)
            }

            for name, idx in COLUMN_MAP.items():
                record[name] = to_float(values[idx]) if idx < len(values) else None

            meta["dados"].append(record)

    return meta