from core.statistics import mean, std_dev, pearson
from core.regression import linear_regression, predict, moving_average, mae


def clamp(value, low, high):
    if value < low:
        return low
    if value > high:
        return high
    return value


def values_by_filter(records, variable, month=None, season=None):
    result = []

    for r in records:
        if month is not None and r["mes"] != month:
            continue

        if season is not None and r["estacao_ano"] != season:
            continue

        if r.get(variable) is not None:
            result.append(r[variable])

    return result


def forecast_variable(records, target_date, variable):
    records = sorted(records, key=lambda r: r["datetime"])

    all_values = [r.get(variable) for r in records if r.get(variable) is not None]

    if len(all_values) < 5:
        return None

    month_values = values_by_filter(records, variable, month=target_date.month)

    if len(month_values) < 3:
        month_values = all_values

    seasonal_mean = mean(month_values)
    seasonal_std = std_dev(month_values) or 0

    x = []
    y = []

    for i, r in enumerate(records):
        if r.get(variable) is not None:
            x.append(i)
            y.append(r[variable])

    model = linear_regression(x, y)

    if model is None:
        trend_pred = seasonal_mean
        model_error = seasonal_std
    else:
        future_x = len(records)
        trend_pred = predict(model, future_x)

        fitted = [predict(model, xi) for xi in x]
        model_error = mae(y, fitted) or seasonal_std

    ma = moving_average(all_values, window=7)
    ma_pred = ma[-1] if ma[-1] is not None else seasonal_mean

    predicted = (
        0.45 * seasonal_mean +
        0.35 * trend_pred +
        0.20 * ma_pred
    )

    uncertainty = seasonal_std + model_error

    if uncertainty == 0:
        confidence = 90
    else:
        confidence = 100 - clamp((uncertainty / max(abs(predicted), 1)) * 100, 5, 95)

    probability_above_mean = 50

    if predicted > seasonal_mean:
        probability_above_mean = 50 + clamp(abs(predicted - seasonal_mean) / max(seasonal_std, 1) * 20, 0, 45)
    elif predicted < seasonal_mean:
        probability_above_mean = 50 - clamp(abs(predicted - seasonal_mean) / max(seasonal_std, 1) * 20, 0, 45)

    return {
        "variavel": variable,
        "valor_previsto": predicted,
        "media_sazonal": seasonal_mean,
        "desvio_sazonal": seasonal_std,
        "probabilidade_acima_media": round(probability_above_mean, 2),
        "confiabilidade": round(confidence, 2),
        "metodo": "regressao_linear_manual + media_movel"
    }


def rain_probability(records, target_date):
    same_month = [r for r in records if r["mes"] == target_date.month]

    if len(same_month) < 3:
        same_month = records

    rain_events = 0
    total = 0

    for r in same_month:
        p = r.get("precipitacao")
        if p is not None:
            total += 1
            if p > 0:
                rain_events += 1

    if total == 0:
        base = 0
    else:
        base = rain_events / total * 100

    humidity = [r.get("umidade") for r in same_month]
    rain = [r.get("precipitacao") for r in same_month]

    r_hum_rain = pearson(humidity, rain)

    adjustment = 0

    if r_hum_rain is not None:
        adjustment += r_hum_rain * 10

    probability = clamp(base + adjustment, 0, 100)

    return {
        "probabilidade_chuva": round(probability, 2),
        "correlacao_umidade_precipitacao": r_hum_rain
    }