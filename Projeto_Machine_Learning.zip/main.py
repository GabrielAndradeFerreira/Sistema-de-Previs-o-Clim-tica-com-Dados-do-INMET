import os
from core.parser import parse_inmet_file
from core.engine import ClimateEngine
from interface import ForecastModal


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "data", "uploads")


def load_all_files():
    engine = ClimateEngine()

    if not os.path.exists(UPLOAD_DIR):
        os.makedirs(UPLOAD_DIR)
        print(f"Pasta criada: {UPLOAD_DIR}")
        print("Coloque os arquivos CSV do INMET nessa pasta.")
        return engine

    files = os.listdir(UPLOAD_DIR)

    if len(files) == 0:
        print(f"Nenhum arquivo encontrado em: {UPLOAD_DIR}")
        return engine

    for filename in files:
        if filename.lower().endswith(".csv"):
            path = os.path.join(UPLOAD_DIR, filename)

            try:
                station = parse_inmet_file(path)
                engine.add_station(station)

                print(f"Arquivo carregado: {filename}")
                print(f"Estação: {station.get('estacao')} - {station.get('cidade')}")

            except Exception as e:
                print(f"Erro ao carregar arquivo {filename}: {e}")

    return engine


if __name__ == "__main__":
    engine = load_all_files()

    app = ForecastModal(engine)
    app.run()