import os
import json
from core.parser import parse_inmet_file
from core.engine import ClimateEngine


UPLOAD_DIR = "data/uploads"


def load_all_files():
    engine = ClimateEngine()

    for filename in os.listdir(UPLOAD_DIR):
        if filename.lower().endswith(".csv"):
            path = os.path.join(UPLOAD_DIR, filename)

            station = parse_inmet_file(path)
            engine.add_station(station)

            print(f"Arquivo carregado: {filename}")
            print(f"Estação: {station.get('estacao')} - {station.get('cidade')}")

    return engine


if __name__ == "__main__":
    engine = load_all_files()

    result = engine.forecast(
        date_str="2027-06-15",
        estado="RS",
        regiao="S"
    )

    print(json.dumps(result, indent=2, ensure_ascii=False))