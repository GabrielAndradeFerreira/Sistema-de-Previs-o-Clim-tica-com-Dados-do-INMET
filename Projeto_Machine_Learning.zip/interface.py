import tkinter as tk
from tkinter import messagebox
from tkinter.scrolledtext import ScrolledText
from datetime import datetime


class ForecastModal:
    def __init__(self, engine):
        self.engine = engine

        self.root = tk.Tk()
        self.root.title("Painel de Previsão Climática - INMET")
        self.root.geometry("780x620")
        self.root.resizable(False, False)

        self.build_ui()

    def build_ui(self):
        title = tk.Label(
            self.root,
            text="Consulta de Previsão Climática",
            font=("Arial", 18, "bold")
        )
        title.pack(pady=15)

        frame = tk.Frame(self.root)
        frame.pack(pady=10)

        city_label = tk.Label(frame, text="Cidade:", font=("Arial", 11))
        city_label.grid(row=0, column=0, padx=5, pady=5, sticky="e")

        self.city_entry = tk.Entry(frame, width=35, font=("Arial", 11))
        self.city_entry.grid(row=0, column=1, padx=5, pady=5)

        date_label = tk.Label(frame, text="Data futura:", font=("Arial", 11))
        date_label.grid(row=1, column=0, padx=5, pady=5, sticky="e")

        self.date_entry = tk.Entry(frame, width=35, font=("Arial", 11))
        self.date_entry.grid(row=1, column=1, padx=5, pady=5)
        self.date_entry.insert(0, "2027-06-15")

        help_label = tk.Label(
            frame,
            text="Formato da data: AAAA-MM-DD",
            font=("Arial", 9),
            fg="gray"
        )
        help_label.grid(row=2, column=1, sticky="w", padx=5)

        button = tk.Button(
            self.root,
            text="Consultar previsão",
            font=("Arial", 12, "bold"),
            command=self.consult_forecast,
            bg="#1f6aa5",
            fg="white",
            width=22
        )
        button.pack(pady=15)

        output_label = tk.Label(
            self.root,
            text="Resultado da previsão:",
            font=("Arial", 12, "bold")
        )
        output_label.pack(anchor="w", padx=35)

        self.output = ScrolledText(
            self.root,
            width=88,
            height=22,
            font=("Consolas", 10)
        )
        self.output.pack(padx=30, pady=10)

        self.city_entry.bind("<Return>", lambda event: self.consult_forecast())
        self.date_entry.bind("<Return>", lambda event: self.consult_forecast())

    def validate_date(self, date_text):
        try:
            return datetime.strptime(date_text, "%Y-%m-%d")
        except:
            return None

    def consult_forecast(self):
        city = self.city_entry.get().strip()
        date_text = self.date_entry.get().strip()

        if city == "":
            messagebox.showwarning(
                "Cidade obrigatória",
                "Informe uma cidade para consultar a previsão."
            )
            return

        target_date = self.validate_date(date_text)

        if target_date is None:
            messagebox.showerror(
                "Data inválida",
                "A data deve estar no formato AAAA-MM-DD.\nExemplo: 2027-06-15"
            )
            return

        stations = self.engine.find_station(cidade=city)

        if len(stations) == 0:
            messagebox.showwarning(
                "Cidade não encontrada",
                f"Nenhum arquivo correspondente à cidade '{city}' foi encontrado na pasta uploads."
            )

            self.output.delete("1.0", tk.END)
            self.output.insert(
                tk.END,
                f"Nenhum dado encontrado para a cidade: {city}\n"
                f"Verifique se existe um CSV do INMET correspondente em data/uploads.\n"
            )
            return

        results = self.engine.forecast(
            date_str=date_text,
            cidade=city
        )

        self.output.delete("1.0", tk.END)

        if len(results) == 0:
            self.output.insert(
                tk.END,
                "Não foi possível gerar previsão para os dados encontrados.\n"
            )
            return

        for result in results:
            self.output.insert(tk.END, self.format_result(result))
            self.output.insert(tk.END, "\n" + "-" * 80 + "\n\n")

    def format_result(self, result):
        corr = result["correlacao_dominante"]

        return f"""
Local consultado:
{result["local_consultado"]}

Estação meteorológica:
{result["estacao"]}

Região climática:
{result["regiao"]}

Data prevista:
{result["periodo"]}

Temperatura média prevista:
{result["temperatura_media_prevista"]} °C

Umidade prevista:
{result["umidade_prevista"]} %

Pressão atmosférica prevista:
{result["pressao_prevista"]} mB

Velocidade do vento prevista:
{result["vento_previsto"]} m/s

Probabilidade de chuva:
{result["probabilidade_chuva"]} %

Correlação dominante:
{corr["variaveis"]} = {corr["valor"]}

Interpretação da correlação:
{corr["interpretacao"]}

Método utilizado:
{result["metodo"]}

Confiabilidade estimada:
{result["confiabilidade"]} %

Explicação:
{result["explicacao"]}
""".strip()

    def run(self):
        self.root.mainloop()